# Merge Options View Prototype

This is a code bundle for Merge Options View Prototype.

## Running the code

Run `npm i` to install the dependencies.

Run `npm run dev` to start the development server.